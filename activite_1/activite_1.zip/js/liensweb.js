/* 
Activité 1
*/

// Liste des liens Web à afficher. Un lien est défini par :
// - son titre
// - son URL
// - son auteur (la personne qui l'a publié)
var listeLiens = [
    {
        titre: "So Foot",
        url: "http://sofoot.com",
        auteur: "yann.usaille"
    },
    {
        titre: "Guide d'autodéfense numérique",
        url: "http://guide.boum.org",
        auteur: "paulochon"
    },
    {
        titre: "L'encyclopédie en ligne Wikipedia",
        url: "http://Wikipedia.org",
        auteur: "annie.zette"
    }
];

// TODO : compléter ce fichier pour ajouter les liens à la page web

//créer les 3 éléments
var lien1 = listeLiens[0].createElement

listeLiens.forEach(function (lienElt) {
    //crée le titre
    var lienTitre = document.createElement("p");
    lienTitre.textContent = lienElt.titre;
    lienTitre.style.color = "#428bca";
    
    //crée le lien
    var lienURL = document.createElement("a");
    lienURL.textContent = " " + lienElt.url;
    lienURL.href = lienElt.url;
    lienURL.style.textDecoration = "none";
    lienURL.style.color = "black";
    
    // titre et lien sur la même ligne
    lienTitre.appendChild(lienURL);
    
    //crée l'auteur
    var lienAuteur = document.createElement("p");
    lienAuteur.textContent = "Ajouté par " + lienElt.auteur;
    
    //ajout des élément au DOM
    document.getElementById("contenu").appendChild(lienTitre);
    document.getElementById("contenu").appendChild(lienAuteur);
})